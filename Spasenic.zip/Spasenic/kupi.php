<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <br>
        <h1>Spisak narucenih proizvoda</h1>
<?php

	session_start();
	$connect = mysqli_connect("localhost", "root", "", "si2");
	


$sql = "SELECT * FROM proizvodi WHERE Kolicina <= 3 ORDER BY Kolicina DESC ";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["ID"]. " - Naziv: " . $row["Naziv"]. " - Kolicina " . $row["Kolicina"]. "<br>";
    }
} else {
    echo "0 results";
}
$connect->close();
?>
        <a href='index.php'>Vrati na pocetnu</a>
    </body>
</html>

