<?php

	session_start();
	$connect = mysqli_connect("localhost", "root", "", "si2");
	
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
		<div style='clear:both'>
			<br>
			<h3>Racun</h3>
			<div class='table-responsive'>
				<table style="border:1px solid black;" class='table table-bordered'>
					<tr>
						<th width="">Naziv</th>
						<th width="">Kolicina</th>
						<th width="">Cena</th>
					</tr>
					<?php
					if (!empty($_SESSION['shopping_cart'])) {
						$total = 0;
						foreach ($_SESSION['shopping_cart'] as $keys => $values) {
					?>
							<tr>
								<td><?php echo $values['item_name'] ?></td>
								<td><?php echo $values['item_quantity'] ?></td>
								<td>$<?php echo $values['item_price'] ?></td>
							</tr>
					<?php
					$total = $total + ($values["item_quantity"] * $values["item_price"]);
						}
					?>
						<tr>
							<td colspan="3"> Total </td>
							<td> $<?php echo number_format($total, 2); ?></td>
						</tr>
				<?php
					}
				?>
				</table>
			</div>
		</div>
	</body>
</html>