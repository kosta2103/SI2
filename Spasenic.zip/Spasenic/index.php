<?php
    session_start();
    $connect = mysqli_connect("localhost", "root", "", "si2");
    if(isset($_POST['add_to_cart']))
    {
        if(isset($_SESSION['shopping_cart']))
        {
            $item_array_id = array_column($_SESSION['shopping_cart'], 'item_id');
            if(!in_array($_GET['ID'], $item_array_id))
            {
                $count = count($_SESSION['shopping_cart']);
                $item_array = array(
                    'item_id'       => $_GET['ID'],
                    'item_name'     => $_POST['name_hidden'],
                    'item_price'    => $_POST['price_hidden'],
                    'item_quantity' => $_POST['quantity']
                );
                $_SESSION['shopping_cart'][$count] = $item_array;
            }
            else{
                echo '<script> alert("Artikal je vec dodat u korpu!") </script>';
                echo '<script> window.location = "index.php" </script>';
            }
        }
        else{
            $item_array = array (
                'item_id'       => $_GET['ID'],
                'item_name'     => $_POST['name_hidden'],
                'item_price'    => $_POST['price_hidden'],
                'item_quantity' => $_POST['quantity']
            );
            $_SESSION['shopping_cart'][0] = $item_array;
        }
    }
    if(isset($_GET['action']))
    {
        if($_GET['action'] == 'delete')
        {
            foreach($_SESSION['shopping_cart'] as $keys=>$values)
            {
                if($values['item_id'] == $_GET['ID'])
                {
                    unset($_SESSION['shopping_cart'][$keys]);
                    echo '<script> alert("Proizvod je obrisan") </script>';
                    echo '<script> window.location = "korpa.php" </script>';
                }
            }
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
            if(!empty($_SESSION["shopping_cart"]))
            {
                $cart_count = count(array_keys($_SESSION["shopping_cart"]));
        ?>
                <div class="cart_div">
                    <a href="korpa.php"><img style="width:10%" src="img/korpa.png" alt=""/><span><?php echo $cart_count; ?> </span> </a>
                </div>
        <?php
            }
        ?>
        <div class="container" style="width:700px;">
            <h3 align='center'>Shopping cart</h3>
            <?php
                $query = "SELECT * FROM proizvodi ORDER BY ID ASC";
                $result = mysqli_query($connect, $query);
                if(mysqli_num_rows($result)>0)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {
                        ?>
                        <div class='col-md-4'>
                            <form method='POST' action='index.php?action=add&ID=<?php echo $row['ID']; ?>'>
                                <div style="border:1px solid black; background-color:#f1f1f1; border-radius: 5px ">
                                    <img src ='<?php echo $row['Slika']; ?> ' class='img-responsive'> <br>
                                    <h4 class='text-info'><?php echo $row['Naziv']; ?></h4>
                                    <h4 class='text-info'>$<?php echo $row['Cena']; ?></h4>
                                    <input type='text' name='quantity' class='form-control' value='1'>
                                    <input type='hidden' name='name_hidden'     value='<?php echo $row['Naziv']; ?>'>
                                    <input type='hidden' name='price_hidden'    value="<?php echo $row['Cena']; ?>">
                                    <input type='submit' name="add_to_cart" style="margin-top: 5px;" class='btn-success' value='Add to cart'>
                                </div>
                            </form>
                        </div>
                        <?php
                    }
                }
            ?>
        </div>
        <br>
        <form action='kupi.php' method='POST'>
            <input type='submit' name='SpisakZaNarucivanje' value='Spisak artikala za narucivanje'>
        </form>
    </body>
</html>
