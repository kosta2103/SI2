<?php

	session_start();
	$connect = mysqli_connect("localhost", "root", "", "si2");
	
	?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <br>
        Posalji spisak narudzbina gde je kolicina 0
        <form action='kupi.php' method='POST'>
            <table>
                <tr>
                    <td><input type='submit' name='naruci' value='Naruci'></td>
                </tr>
            </table>
        </form>
    </body>
</html>